package com.example.day1_q5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1Q5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
