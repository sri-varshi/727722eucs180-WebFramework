package com.example.day1_q5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1Q5Application {

	public static void main(String[] args) {
		SpringApplication.run(Day1Q5Application.class, args);
	}

}
