package com.example.day_1_q1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1Q1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day1Q1Application.class, args);
	}

}
