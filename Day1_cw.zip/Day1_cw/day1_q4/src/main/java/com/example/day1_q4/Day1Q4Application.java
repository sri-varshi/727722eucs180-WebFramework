package com.example.day1_q4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1Q4Application {

	public static void main(String[] args) {
		SpringApplication.run(Day1Q4Application.class, args);
	}

}
