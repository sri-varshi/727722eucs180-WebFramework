package com.example.day1_q4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1Q4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
